# Business Email Extractor Web App

Deploy with Streamlit Community Cloud. Main file: `app.py`.
The app accepts URLs or a TXT/CSV list and exports extracted public business emails.
